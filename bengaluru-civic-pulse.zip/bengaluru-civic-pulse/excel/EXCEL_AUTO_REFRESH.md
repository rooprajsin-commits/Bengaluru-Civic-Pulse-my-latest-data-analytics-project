# Excel auto-refresh setup (Power Query)

`Civic_Pulse_Dashboard.xlsx` already works as a snapshot. This one-time setup connects it to the
pipeline's CSVs so it refreshes itself every minute during your showcase.

## Sheets
| Sheet | What it is |
|---|---|
| **Dashboard** | KPI tiles, zone table (data bars), rain-impact stats (CORREL, AVERAGEIFS), 5 charts |
| **Ward Lookup** | Pick any ward from the dropdown; INDEX/MATCH pulls its scorecard |
| **Calc** | Fixed-size helper tables feeding the charts (formulas only) |
| **q_*** | Raw query output - the only sheets Power Query writes to |

## Connect each q_ sheet to its CSV
| Sheet | CSV in `data/processed/` |
|---|---|
| q_kpi | vw_kpi_summary.csv |
| q_zone | vw_zone_summary.csv |
| q_category | vw_category_sla.csv |
| q_monthly | vw_monthly_trend.csv |
| q_wards | vw_ward_scorecard.csv |
| q_rain | vw_daily_rain_vs_complaints.csv |
| q_aqi | vw_air_quality_latest.csv |

For each row:
1. Open the q_ sheet, click A1, press **Ctrl+A** then **Delete** (clear contents - do **not** delete the sheet,
   or the Dashboard formulas break).
2. **Data > Get Data > From File > From Text/CSV** > pick the CSV > **Load To...**
3. Choose **Table** > **Existing worksheet** > `=q_zone!$A$1` (the sheet you're on) > OK.

## Turn on auto refresh
1. **Data > Queries & Connections**.
2. Right-click a query > **Properties**:
   - tick **Refresh every 1 minutes**
   - tick **Refresh data when opening the file**
3. Repeat for all 7 queries. Save.

## Showcase
1. Terminal: `python src/run_pipeline.py --loop 1`
2. Open the workbook on the Dashboard sheet.
3. Every minute the pipeline adds new complaints and updates statuses; Excel pulls them in and the
   **Last refreshed** time, KPI tiles and charts change in front of the interviewer.

Tip: if a refresh ever says the file is in use, it will succeed on the next cycle - the pipeline
writes each CSV to a temp file and swaps it in, so Excel never reads half a file.
