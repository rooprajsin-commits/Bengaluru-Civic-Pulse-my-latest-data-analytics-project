"""
Grievance data source.

1. If data/raw/bbmp_grievances_real.csv exists (a real BBMP grievance export, e.g. from
   OpenCity / data.gov.in), it is standardised and used.
2. Otherwise a realistic prototype dataset is simulated for 48 real Bengaluru wards across the
   8 BBMP zones. The simulation is driven by the REAL daily rainfall from the weather API,
   so rain-sensitive categories (potholes, waterlogging, fallen trees) genuinely spike on
   rainy days - something the analysis then has to discover.

LIVE MODE: each pipeline run appends the complaints that "arrived" since the last run, and
complaint status (Registered -> In Progress -> Resolved/Closed) is derived from the current
time, so every refresh changes the numbers on the Excel and Power BI dashboards.
"""
import logging

import numpy as np
import pandas as pd

import config

log = logging.getLogger("civic_pulse.data")
STATE_FILE = config.RAW_DIR / "grievances_stream.csv"

# Zones differ in how fast they close complaints (multiplier on resolution time).
ZONE_SPEED = {"East": 0.85, "West": 0.80, "South": 0.90, "Mahadevapura": 1.35,
              "Bommanahalli": 1.25, "Yelahanka": 1.05, "RR Nagar": 1.15, "Dasarahalli": 1.20}
# Complaint burden per zone (fast-growing peripheral zones raise more issues per resident).
ZONE_BURDEN = {"East": 1.0, "West": 0.85, "South": 0.95, "Mahadevapura": 1.45,
               "Bommanahalli": 1.30, "Yelahanka": 1.05, "RR Nagar": 1.10, "Dasarahalli": 1.20}
# Some departments close complaints faster than others (multiplier on SLA-based resolution time).
CATEGORY_SPEED = {"Garbage & Waste": 0.75, "Roads & Potholes": 1.15, "Streetlights": 0.80,
                  "Drainage & Waterlogging": 1.10, "Stray Animals": 0.95, "Trees & Parks": 0.90,
                  "Mosquito & Health": 0.85, "Encroachment & Others": 1.05}
HOUR_WEIGHTS = np.array([1, 1, 1, 1, 1, 2, 4, 7, 9, 10, 10, 9, 8, 8, 8, 8, 8, 8, 9, 9, 8, 6, 3, 2], float)
HOUR_WEIGHTS /= HOUR_WEIGHTS.sum()


def load_wards() -> pd.DataFrame:
    return pd.read_csv(config.RAW_DIR / "bbmp_wards.csv")


def _simulate(start: pd.Timestamp, end: pd.Timestamp, wards: pd.DataFrame,
              weather: pd.DataFrame, next_id: int, rng) -> pd.DataFrame:
    """Simulate complaints created in [start, end)."""
    rain = weather.assign(date=pd.to_datetime(weather["date"])).set_index(["zone", "date"])["rain_mm"]
    cats = list(config.CATEGORIES)
    shares = np.array([config.CATEGORIES[c]["share"] for c in cats])
    rain_k = np.array([config.CATEGORIES[c]["rain"] for c in cats])
    chan_names, chan_p = list(config.CHANNELS), np.array(list(config.CHANNELS.values()))
    # stable per-ward "personality" (same every run, so live refreshes stay consistent)
    ward_rng = np.random.default_rng(config.RANDOM_SEED + 7)
    ward_factor = dict(zip(wards["ward_no"], ward_rng.lognormal(0, 0.22, len(wards))))
    out = []
    day = start.normalize()
    while day < end:
        seg_start, seg_end = max(start, day), min(end, day + pd.Timedelta(days=1))
        frac = (seg_end - seg_start) / pd.Timedelta(days=1)
        weekday_boost = 1.18 if day.dayofweek == 0 else (0.8 if day.dayofweek == 6 else 1.0)
        for w in wards.itertuples():
            r_today = rain.get((w.zone, day), 0.0)
            r_prev = rain.get((w.zone, day - pd.Timedelta(days=1)), 0.0)
            rain_index = np.log1p(0.6 * r_today + 0.4 * r_prev)          # diminishing effect
            lam = (w.population / 10_000) * config.BASE_DAILY_RATE_PER_10K * weekday_boost \
                  * ZONE_BURDEN[w.zone] * ward_factor[w.ward_no] \
                  * shares * (1 + rain_k * rain_index * 0.55) * frac
            counts = rng.poisson(lam)
            for ci, n in enumerate(counts):
                if n == 0:
                    continue
                cat = cats[ci]
                meta = config.CATEGORIES[cat]
                # timestamps inside the segment, weighted toward day-time hours
                hrs = rng.choice(24, size=n, p=HOUR_WEIGHTS) + rng.random(n)
                ts = day + pd.to_timedelta(hrs, unit="h")
                ts = ts.where((ts >= seg_start) & (ts < seg_end),
                              seg_start + (seg_end - seg_start) * rng.random(n))
                # planned resolution time: lognormal around SLA x zone speed, some breach SLA
                res_h = rng.lognormal(np.log(meta["sla_hrs"] * 0.75 * ZONE_SPEED[w.zone]
                                             * CATEGORY_SPEED[cat] * ward_factor[w.ward_no] ** 0.5), 0.6, n)
                rejected = rng.random(n) < 0.04
                for k in range(n):
                    out.append({
                        "complaint_id": f"GRV{next_id:07d}",
                        "created_at": ts[k].floor("min"),
                        "ward_no": w.ward_no,
                        "category": cat,
                        "sub_category": rng.choice(meta["subs"]),
                        "channel": rng.choice(chan_names, p=chan_p),
                        "planned_resolution_hrs": round(float(res_h[k]), 1),
                        "is_rejected": bool(rejected[k]),
                        "citizen_rating": None,
                    })
                    next_id += 1
        day += pd.Timedelta(days=1)
    df = pd.DataFrame(out)
    if len(df):
        # citizen feedback (1-5): better when resolved within SLA
        sla = df["category"].map(lambda c: config.CATEGORIES[c]["sla_hrs"])
        good = df["planned_resolution_hrs"] <= sla
        df["citizen_rating"] = np.where(good, rng.choice([3, 4, 5], len(df), p=[.2, .45, .35]),
                                        rng.choice([1, 2, 3, 4], len(df), p=[.3, .35, .25, .1]))
    return df


def _load_real(path) -> pd.DataFrame:
    """Map a real BBMP grievance export onto the project schema (edit COLUMN_MAP to match your file)."""
    COLUMN_MAP = {"Complaint ID": "complaint_id", "Grievance Date": "created_at",
                  "Ward Name": "ward_name", "Category": "category", "Sub Category": "sub_category",
                  "Grievance Status": "status_raw", "Staff Remarks": "remarks"}
    df = pd.read_csv(path).rename(columns=COLUMN_MAP)
    df["created_at"] = pd.to_datetime(df["created_at"], errors="coerce", dayfirst=True)
    wards = load_wards()
    df = df.merge(wards[["ward_no", "ward_name"]], on="ward_name", how="left")
    log.info("Loaded %s real grievance rows (%s matched to ward master)", len(df), df["ward_no"].notna().sum())
    return df


def get_grievances(weather: pd.DataFrame, now: pd.Timestamp | None = None) -> pd.DataFrame:
    if config.REAL_GRIEVANCE_CSV.exists():
        return _load_real(config.REAL_GRIEVANCE_CSV)

    now = (now or pd.Timestamp.now()).floor("min")
    wards = load_wards()
    if STATE_FILE.exists():
        hist = pd.read_csv(STATE_FILE, parse_dates=["created_at"])
        last = hist["created_at"].max()
        next_id = int(hist["complaint_id"].str[3:].astype(int).max()) + 1
        rng = np.random.default_rng(int(now.timestamp()) % 2**31)
        new = _simulate(last + pd.Timedelta(minutes=1), now, wards, weather, next_id, rng)
        df = pd.concat([hist, new], ignore_index=True) if len(new) else hist
        log.info("Live stream: +%s new complaints since %s", len(new), last)
    else:
        rng = np.random.default_rng(config.RANDOM_SEED)
        df = _simulate(pd.Timestamp(config.HISTORY_START), now, wards, weather, 1, rng)
        log.info("Generated %s historical complaints", len(df))
    df.to_csv(STATE_FILE, index=False)
    return df
