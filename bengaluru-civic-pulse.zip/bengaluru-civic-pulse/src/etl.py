"""
TRANSFORM + LOAD + EXPORT

transform  : derive status / resolution time / SLA breach as of 'now', build dimensions
load       : SQLite star schema (sql/01_schema.sql) + reporting views (sql/02_views.sql)
             optional: mirror the star schema into PostgreSQL for Power BI DirectQuery
export     : every table and view -> data/processed/*.csv (read by Excel & Power BI)
"""
import io
import logging
import os
import sqlite3
import time

import numpy as np
import pandas as pd

import config

log = logging.getLogger("civic_pulse.etl")


# ------------------------------------------------------------------ transform
def build_dim_date(start: str, end: pd.Timestamp) -> pd.DataFrame:
    d = pd.DataFrame({"date": pd.date_range(start, end.normalize(), freq="D")})
    season_map = {12: "Winter", 1: "Winter", 2: "Winter", 3: "Summer", 4: "Summer", 5: "Summer",
                  6: "SW Monsoon", 7: "SW Monsoon", 8: "SW Monsoon", 9: "SW Monsoon",
                  10: "NE Monsoon", 11: "NE Monsoon"}
    out = pd.DataFrame({
        "date": d["date"].dt.strftime("%Y-%m-%d"),
        "year": d["date"].dt.year,
        "month": d["date"].dt.month,
        "month_name": d["date"].dt.strftime("%b"),
        "year_month": d["date"].dt.strftime("%Y-%m"),
        "quarter": d["date"].dt.year.astype(str) + "-Q" + d["date"].dt.quarter.astype(str),
        "day_name": d["date"].dt.day_name(),
        "is_weekend": (d["date"].dt.dayofweek >= 5).astype(int),
        "season": d["date"].dt.month.map(season_map),
    })
    return out


def transform_grievances(raw: pd.DataFrame, now: pd.Timestamp) -> pd.DataFrame:
    g = raw.copy()
    g["created_at"] = pd.to_datetime(g["created_at"])
    g = g.dropna(subset=["created_at", "ward_no"])                       # data-quality rules
    g = g[g["created_at"] <= now].drop_duplicates("complaint_id")
    g["ward_no"] = g["ward_no"].astype(int)
    g["sla_hours"] = g["category"].map(lambda c: config.CATEGORIES.get(c, {}).get("sla_hrs", 72))

    elapsed = (now - g["created_at"]).dt.total_seconds() / 3600
    planned = g["planned_resolution_hrs"].astype(float)
    rejected = g["is_rejected"].astype(str).str.lower().isin(["true", "1"])
    done = (planned <= elapsed) & ~rejected

    g["status"] = np.select(
        [rejected, done & (elapsed - planned > 48), done, elapsed < 4],
        ["Rejected", "Closed", "Resolved", "Registered"], default="In Progress")
    g["is_open"] = g["status"].isin(["Registered", "In Progress"]).astype(int)
    g["resolution_hours"] = np.where(done, planned.round(1), np.nan)
    g["resolved_at"] = np.where(done, (g["created_at"] + pd.to_timedelta(planned, unit="h"))
                                .dt.strftime("%Y-%m-%d %H:%M:%S"), None)
    g["age_hours"] = np.where(g["is_open"] == 1, elapsed.round(1), g["resolution_hours"])
    g["sla_breached"] = np.where(rejected, 0,
                                 np.where(done, planned > g["sla_hours"], elapsed > g["sla_hours"])).astype(int)
    g["citizen_rating"] = np.where(g["status"] == "Closed", g["citizen_rating"], np.nan)
    g["created_date"] = g["created_at"].dt.strftime("%Y-%m-%d")
    g["created_hour"] = g["created_at"].dt.hour
    g["created_at"] = g["created_at"].dt.strftime("%Y-%m-%d %H:%M:%S")
    cols = ["complaint_id", "created_at", "created_date", "created_hour", "ward_no", "category",
            "sub_category", "channel", "status", "is_open", "resolved_at", "resolution_hours",
            "age_hours", "sla_hours", "sla_breached", "citizen_rating"]
    return g[cols].sort_values("created_at").reset_index(drop=True)


def transform_all(raw_griev, weather, aq, wards, now):
    dim_ward = wards.assign(density_per_sq_km=(wards["population"] / wards["area_sq_km"]).round(0))
    dim_category = pd.DataFrame([{"category": c, "sla_hours": m["sla_hrs"], "rain_sensitive": int(m["rain"] >= 0.6)}
                                 for c, m in config.CATEGORIES.items()])
    dim_date = build_dim_date(config.HISTORY_START, now)
    w = weather.copy()
    w["date"] = pd.to_datetime(w["date"]).dt.strftime("%Y-%m-%d")
    w = w[w["date"].isin(dim_date["date"])]
    a = aq.copy()
    a["timestamp"] = pd.to_datetime(a["timestamp"]).dt.strftime("%Y-%m-%d %H:%M:%S")
    dim_zone = pd.DataFrame([{"zone": z, "latitude": la, "longitude": lo} for z, (la, lo) in config.ZONES.items()])
    return {
        "dim_zone": dim_zone,
        "dim_ward": dim_ward,
        "dim_category": dim_category,
        "dim_date": dim_date,
        "fact_grievance": transform_grievances(raw_griev, now),
        "fact_weather_daily": w,
        "fact_air_quality_hourly": a.drop_duplicates(["zone", "timestamp"]),
    }


# ------------------------------------------------------------------ load
def load_sqlite(tables: dict) -> sqlite3.Connection:
    con = sqlite3.connect(config.DB_PATH)
    con.executescript((config.SQL_DIR / "01_schema.sql").read_text())
    for name, df in tables.items():
        df.to_sql(name, con, if_exists="append", index=False)
    con.executescript((config.SQL_DIR / "02_views.sql").read_text())
    con.commit()
    return con


def log_refresh(con, rows, new_rows, weather_src, aq_src, secs, now):
    con.execute("INSERT INTO etl_refresh_log (refreshed_at, grievance_rows, new_rows, weather_source, "
                "aq_source, duration_sec) VALUES (?,?,?,?,?,?)",
                (now.strftime("%Y-%m-%d %H:%M:%S"), rows, new_rows, weather_src, aq_src, round(secs, 2)))
    con.commit()


def load_postgres(tables: dict):
    """Optional: mirror the star schema into PostgreSQL so Power BI can use DirectQuery +
    Automatic Page Refresh (true live dashboard). Enabled when CIVIC_PG_DSN is set."""
    if not config.PG_DSN:
        return
    import psycopg2  # pip install psycopg2-binary

    def pg_type(col, dtype):
        if col in ("created_at", "resolved_at", "timestamp"):
            return "TIMESTAMP"
        if col in ("date", "created_date"):
            return "DATE"
        if pd.api.types.is_integer_dtype(dtype):
            return "BIGINT"
        if pd.api.types.is_float_dtype(dtype):
            return "DOUBLE PRECISION"
        return "TEXT"

    with psycopg2.connect(config.PG_DSN) as pg, pg.cursor() as cur:
        for name, df in tables.items():
            cols = ", ".join(f'"{c}" {pg_type(c, t)}' for c, t in df.dtypes.items())
            cur.execute(f'CREATE TABLE IF NOT EXISTS {name} ({cols})')
            buf = io.StringIO()
            df.to_csv(buf, index=False, header=False)
            buf.seek(0)
            cur.execute(f"TRUNCATE {name}")          # same transaction -> readers never see it empty
            cur.copy_expert(f"COPY {name} FROM STDIN WITH (FORMAT csv, NULL '')", buf)
        pg.commit()
    log.info("PostgreSQL mirror refreshed (%s tables)", len(tables))


# ------------------------------------------------------------------ export
def _atomic_csv(df: pd.DataFrame, path):
    tmp = path.with_suffix(".tmp")
    df.to_csv(tmp, index=False)
    for attempt in range(5):                       # Excel/Power BI may briefly hold the file
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            time.sleep(1.5)
    log.warning("Could not replace %s (file locked) - keeping previous version", path.name)


EXPORT_VIEWS = ["vw_kpi_summary", "vw_zone_summary", "vw_ward_scorecard", "vw_monthly_trend",
                "vw_category_sla", "vw_daily_rain_vs_complaints", "vw_hourly_pattern",
                "vw_channel_mix", "vw_air_quality_latest", "etl_refresh_log"]


def export_csv(con: sqlite3.Connection, tables: dict):
    for name, df in tables.items():                  # star schema for Power BI
        _atomic_csv(df, config.PROCESSED_DIR / f"{name}.csv")
    for v in EXPORT_VIEWS:                           # ready-made summaries for Excel
        _atomic_csv(pd.read_sql(f"SELECT * FROM {v}", con), config.PROCESSED_DIR / f"{v}.csv")
