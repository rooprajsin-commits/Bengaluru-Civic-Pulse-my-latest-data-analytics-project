"""
Builds excel/Civic_Pulse_Dashboard.xlsx from the CSVs in data/processed/.

Design: the q_* sheets hold raw query output (a snapshot now; replaced by Power Query
connections that auto-refresh every minute - see excel/EXCEL_AUTO_REFRESH.md).
Everything on 'Dashboard', 'Ward Lookup' and 'Calc' is a FORMULA reading the q_* sheets,
so the dashboard recalculates the moment the data refreshes.

    python src/build_excel_dashboard.py           # skips if the workbook exists
    python src/build_excel_dashboard.py --force   # rebuild (removes Power Query connections)
"""
import pandas as pd
from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.comments import Comment
from openpyxl.formatting.rule import CellIsRule, DataBarRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

import config

OUT = config.ROOT / "excel" / "Civic_Pulse_Dashboard.xlsx"
NAVY, BLUE, ORANGE, AQUA = "1F2A44", "2A78D6", "EB6834", "1BAF7A"
INK, MUTED, LINE, TILE = "0B0B0B", "52514E", "D9D8D3", "F4F6FA"
F = "Arial"
thin = Side(style="thin", color=LINE)

# query sheet name -> source CSV
QUERIES = {
    "q_kpi": "vw_kpi_summary", "q_zone": "vw_zone_summary", "q_category": "vw_category_sla",
    "q_monthly": "vw_monthly_trend", "q_wards": "vw_ward_scorecard",
    "q_rain": "vw_daily_rain_vs_complaints", "q_aqi": "vw_air_quality_latest",
}
ZONES = list(config.ZONES)
CATS = list(config.CATEGORIES)
BANDS = ["0 Dry", "1 Light (<5mm)", "2 Moderate (5-20mm)", "3 Heavy (20mm+)"]


def style_header(cells, fill=NAVY):
    for c in cells:
        c.font = Font(name=F, bold=True, color="FFFFFF", size=10)
        c.fill = PatternFill("solid", fgColor=fill)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = Border(bottom=thin)


def body(c, fmt=None, bold=False, align=None, color=INK):
    c.font = Font(name=F, size=10, bold=bold, color=color)
    c.border = Border(bottom=thin)
    if fmt:
        c.number_format = fmt
    if align:
        c.alignment = Alignment(horizontal=align, vertical="center")


def write_query_sheets(wb):
    for sheet, csv in QUERIES.items():
        ws = wb.create_sheet(sheet)
        df = pd.read_csv(config.PROCESSED_DIR / f"{csv}.csv")
        ws.append(list(df.columns))
        for row in df.itertuples(index=False):
            ws.append([None if pd.isna(v) else v for v in row])
        style_header(ws[1])
        for i, col in enumerate(df.columns, 1):
            ws.column_dimensions[get_column_letter(i)].width = max(12, min(28, len(col) + 4))
            for c in ws.iter_cols(min_col=i, max_col=i, min_row=2):
                for cell in c:
                    cell.font = Font(name=F, size=10)
        ws.freeze_panes = "A2"
        ws["A1"].comment = Comment(f"Source: data/processed/{csv}.csv - replace with a Power Query "
                                   f"connection (see EXCEL_AUTO_REFRESH.md).", "Civic Pulse")
        ws.sheet_properties.tabColor = "8A8984"


def build_calc(wb):
    """Helper tables (all formulas) that feed the charts - fixed size, so charts never break."""
    ws = wb.create_sheet("Calc", 1)
    ws.sheet_properties.tabColor = MUTED
    ws["A1"] = "Chart helper tables - formulas only, do not type here"
    ws["A1"].font = Font(name=F, bold=True, size=11)

    # Zone table (rows 3-11)
    hdr = ["Zone", "Complaints", "Per 10k residents", "Open", "Avg resolution (hrs)", "SLA breach %", "Avg rating"]
    src_cols = ["D", "E", "F", "G", "H", "I"]       # q_zone columns
    for j, h in enumerate(hdr):
        ws.cell(3, 1 + j, h)
    style_header(ws[3][:len(hdr)])
    for i, z in enumerate(ZONES):
        r = 4 + i
        ws.cell(r, 1, z)
        for j, col in enumerate(src_cols):
            ws.cell(r, 2 + j, f'=IFERROR(INDEX(q_zone!${col}:${col},MATCH($A{r},q_zone!$A:$A,0)),0)')

    # Category table (rows 14-22)
    hdr = ["Category", "Complaints", "Share %", "Open", "Avg resolution (hrs)", "SLA breach %", "Avg rating"]
    src_cols = ["D", "E", "F", "G", "H", "I"]       # q_category columns
    for j, h in enumerate(hdr):
        ws.cell(14, 1 + j, h)
    style_header(ws[14][:len(hdr)])
    for i, c in enumerate(CATS):
        r = 15 + i
        ws.cell(r, 1, c)
        for j, col in enumerate(src_cols):
            ws.cell(r, 2 + j, f'=IFERROR(INDEX(q_category!${col}:${col},MATCH($A{r},q_category!$A:$A,0)),0)')

    # Last 12 months (rows 25-37) - always the latest 12 rows of q_monthly
    for j, h in enumerate(["Month", "Complaints", "Rain-sensitive", "SLA breach %", "City rain (mm)"]):
        ws.cell(25, 1 + j, h)
    style_header(ws[25][:5])
    for k in range(12):
        r = 26 + k
        idx = f"COUNTA(q_monthly!$A:$A)-11+{k}"
        ws.cell(r, 1, f"=IFERROR(INDEX(q_monthly!$A:$A,{idx}),\"\")")
        ws.cell(r, 2, f"=IFERROR(INDEX(q_monthly!$B:$B,{idx}),0)")
        ws.cell(r, 3, f"=IFERROR(INDEX(q_monthly!$C:$C,{idx}),0)")
        ws.cell(r, 4, f"=IFERROR(INDEX(q_monthly!$E:$E,{idx}),0)")
        ws.cell(r, 5, f"=IFERROR(INDEX(q_monthly!$F:$F,{idx}),0)")

    # Rain band analysis (rows 40-44) - AVERAGEIFS over the daily table
    for j, h in enumerate(["Rain band", "Days", "Pothole / day", "Waterlogging / day", "All complaints / day"]):
        ws.cell(40, 1 + j, h)
    style_header(ws[40][:5])
    for i, b in enumerate(BANDS):
        r = 41 + i
        ws.cell(r, 1, b)
        ws.cell(r, 2, f'=COUNTIF(q_rain!$H:$H,$A{r})')
        ws.cell(r, 3, f'=IFERROR(AVERAGEIFS(q_rain!$D:$D,q_rain!$H:$H,$A{r}),0)')
        ws.cell(r, 4, f'=IFERROR(AVERAGEIFS(q_rain!$E:$E,q_rain!$H:$H,$A{r}),0)')
        ws.cell(r, 5, f'=IFERROR(AVERAGEIFS(q_rain!$B:$B,q_rain!$H:$H,$A{r}),0)')

    # Air quality by zone (rows 47-55)
    for j, h in enumerate(["Zone", "US AQI (latest)", "AQI 24h avg", "PM2.5", "Band"]):
        ws.cell(47, 1 + j, h)
    style_header(ws[47][:5])
    for i, z in enumerate(ZONES):
        r = 48 + i
        ws.cell(r, 1, z)
        for j, col in enumerate(["E", "F", "C", "G"]):
            ws.cell(r, 2 + j, f'=IFERROR(INDEX(q_aqi!${col}:${col},MATCH($A{r},q_aqi!$A:$A,0)),"")')

    for row in ws.iter_rows(min_row=4, max_row=55):
        for c in row:
            if c.row not in (14, 25, 40, 47) and c.value is not None:
                body(c, fmt="#,##0.0" if c.column > 1 else None)
    ws.column_dimensions["A"].width = 26
    for col in "BCDEFG":
        ws.column_dimensions[col].width = 16
    return ws


def kpi_tile(ws, col, label, formula, fmt, note=None):
    c1, c2 = get_column_letter(col), get_column_letter(col + 1)
    ws.merge_cells(f"{c1}5:{c2}5")
    ws.merge_cells(f"{c1}6:{c2}7")
    ws[f"{c1}5"] = label
    ws[f"{c1}5"].font = Font(name=F, size=9, bold=True, color=MUTED)
    ws[f"{c1}6"] = formula
    ws[f"{c1}6"].font = Font(name=F, size=20, bold=True, color=NAVY)
    ws[f"{c1}6"].number_format = fmt
    for r in (5, 6, 7):
        for cc in (col, col + 1):
            ws.cell(r, cc).fill = PatternFill("solid", fgColor=TILE)
            ws.cell(r, cc).alignment = Alignment(horizontal="center", vertical="center")
    if note:
        ws[f"{c1}6"].comment = Comment(note, "Civic Pulse")


def bar_chart(title, data_ref, cats_ref, color, horizontal=True, fmt="0"):
    ch = BarChart()
    ch.type = "bar" if horizontal else "col"
    ch.title = title
    ch.style = 2
    ch.add_data(data_ref, titles_from_data=True)
    ch.set_categories(cats_ref)
    ch.legend = None
    s = ch.series[0]
    s.graphicalProperties.solidFill = color
    s.graphicalProperties.line.noFill = True
    s.dLbls = DataLabelList()
    s.dLbls.showVal = True
    s.dLbls.showSerName = s.dLbls.showCatName = s.dLbls.showLegendKey = s.dLbls.showPercent = False
    s.dLbls.numFmt = fmt
    ch.gapWidth = 60
    ch.y_axis.majorGridlines = None
    ch.y_axis.delete = True
    ch.x_axis.delete = False
    ch.height, ch.width = 7.5, 15
    return ch


def build_dashboard(wb, calc):
    ws = wb.active
    ws.title = "Dashboard"
    ws.sheet_view.showGridLines = False
    ws.sheet_properties.tabColor = BLUE
    for col in range(1, 16):
        ws.column_dimensions[get_column_letter(col)].width = 11
    ws.column_dimensions["A"].width = 2

    ws.merge_cells("B2:I2")
    ws["B2"] = "Bengaluru Civic Pulse  |  BBMP Grievance & Air-Quality Dashboard"
    ws["B2"].font = Font(name=F, size=18, bold=True, color=NAVY)
    ws.merge_cells("B3:I3")
    ws["B3"] = "Python ETL  >  Open-Meteo API  >  SQL warehouse  >  Power Query auto-refresh (every 1 min)"
    ws["B3"].font = Font(name=F, size=10, color=MUTED)
    ws["K2"] = "Last refreshed"
    ws["K2"].font = Font(name=F, size=9, bold=True, color=MUTED)
    ws.merge_cells("K3:M3")
    ws["K3"] = "=q_kpi!J2"
    ws["K3"].font = Font(name=F, size=11, bold=True, color=ORANGE)
    ws["K3"].number_format = "dd-mmm-yyyy hh:mm"

    kpi_tile(ws, 2, "TOTAL COMPLAINTS", "=q_kpi!A2", "#,##0")
    kpi_tile(ws, 4, "OPEN NOW", "=q_kpi!B2", "#,##0")
    kpi_tile(ws, 6, "RESOLUTION RATE", "=q_kpi!D2", "0.0%", "Resolved+Closed / all non-rejected complaints")
    kpi_tile(ws, 8, "AVG RESOLUTION (HRS)", "=q_kpi!E2", "0.0")
    kpi_tile(ws, 10, "SLA BREACH RATE", "=q_kpi!F2", "0.0%", "Share of complaints that took longer than the category SLA")
    kpi_tile(ws, 12, "CITIZEN RATING (/5)", "=q_kpi!G2", "0.00")
    kpi_tile(ws, 14, "COMPLAINTS TODAY", "=q_kpi!H2", "#,##0")
    ws.column_dimensions["O"].width = 11

    # zone table
    ws["B9"] = "Zone performance"
    ws["B9"].font = Font(name=F, size=12, bold=True, color=NAVY)
    headers = ["Zone", "", "Complaints", "Per 10k", "Open", "Avg hrs", "SLA breach %", "Rating"]
    for j, h in enumerate(headers):
        ws.cell(10, 2 + j, h)
    ws.merge_cells("B10:C10")
    style_header([ws.cell(10, 2 + j) for j in range(len(headers))])
    for i in range(len(ZONES)):
        r, cr = 11 + i, 4 + i
        ws.merge_cells(f"B{r}:C{r}")
        ws[f"B{r}"] = f"=Calc!A{cr}"
        body(ws[f"B{r}"], bold=True)
        for j, (cc, fmt) in enumerate([("B", "#,##0"), ("C", "#,##0"), ("D", "#,##0"), ("E", "0.0"),
                                       ("F", "0.0"), ("G", "0.00")]):
            cell = ws.cell(r, 4 + j, f"=Calc!{cc}{cr}")
            body(cell, fmt=fmt, align="center")
    ws.conditional_formatting.add("H11:H18", DataBarRule(start_type="num", start_value=0, end_type="num",
                                                         end_value=100, color=ORANGE))
    ws.conditional_formatting.add("I11:I18", CellIsRule(operator="lessThan", formula=["3.3"],
                                                        font=Font(color="C0392B", bold=True)))

    # rain insight box
    ws["B20"] = "Rain effect (live API weather)"
    ws["B20"].font = Font(name=F, size=12, bold=True, color=NAVY)
    ws["B21"] = "Correlation: daily rain vs rain-sensitive complaints"
    ws["B21"].font = Font(name=F, size=10, color=MUTED)
    ws["H21"] = "=IFERROR(CORREL(q_rain!$F:$F,q_rain!$C:$C),0)"
    ws["H21"].number_format = "0.00"
    ws["H21"].font = Font(name=F, size=12, bold=True, color=NAVY)
    ws["B22"] = "Pothole complaints: heavy-rain day vs dry day"
    ws["B22"].font = Font(name=F, size=10, color=MUTED)
    ws["H22"] = "=IFERROR(Calc!C44/Calc!C41-1,0)"
    ws["H22"].number_format = "+0%;-0%"
    ws["H22"].font = Font(name=F, size=12, bold=True, color=ORANGE)
    ws["B23"] = "Waterlogging complaints: heavy-rain day vs dry day"
    ws["B23"].font = Font(name=F, size=10, color=MUTED)
    ws["H23"] = "=IFERROR(Calc!D44/Calc!D41-1,0)"
    ws["H23"].number_format = "+0%;-0%"
    ws["H23"].font = Font(name=F, size=12, bold=True, color=ORANGE)

    # charts
    zc = bar_chart("Complaints per 10k residents by zone",
                   Reference(calc, min_col=3, min_row=3, max_row=11), Reference(calc, min_col=1, min_row=4, max_row=11), BLUE)
    ws.add_chart(zc, "L9")
    lc = LineChart()
    lc.title = "Monthly complaints (last 12 months)"
    lc.style = 2
    lc.add_data(Reference(calc, min_col=2, max_col=3, min_row=25, max_row=37), titles_from_data=True)
    lc.set_categories(Reference(calc, min_col=1, min_row=26, max_row=37))
    lc.series[0].graphicalProperties.line.solidFill = BLUE
    lc.series[0].graphicalProperties.line.width = 28000
    lc.series[1].graphicalProperties.line.solidFill = ORANGE
    lc.series[1].graphicalProperties.line.width = 22000
    for ser in lc.series:
        ser.smooth = False
    lc.y_axis.number_format = "#,##0"
    lc.y_axis.majorGridlines.spPr = None
    lc.legend.position = "b"
    lc.height, lc.width = 7.5, 15
    ws.add_chart(lc, "B26")
    cc = bar_chart("SLA breach % by category", Reference(calc, min_col=6, min_row=14, max_row=22),
                   Reference(calc, min_col=1, min_row=15, max_row=22), ORANGE, fmt='0"%"')
    ws.add_chart(cc, "L26")
    rc = bar_chart("Pothole complaints per day, by rain band", Reference(calc, min_col=3, min_row=40, max_row=44),
                   Reference(calc, min_col=1, min_row=41, max_row=44), BLUE, horizontal=False)
    ws.add_chart(rc, "B42")
    ac = bar_chart("Live air quality - US AQI by zone (Open-Meteo)", Reference(calc, min_col=2, min_row=47, max_row=55),
                   Reference(calc, min_col=1, min_row=48, max_row=55), AQUA)
    ws.add_chart(ac, "L42")


def build_ward_lookup(wb):
    ws = wb.create_sheet("Ward Lookup", 1)
    ws.sheet_view.showGridLines = False
    ws.sheet_properties.tabColor = AQUA
    ws.column_dimensions["A"].width = 2
    ws.column_dimensions["B"].width = 34
    ws.column_dimensions["C"].width = 26
    ws["B2"] = "Ward Lookup"
    ws["B2"].font = Font(name=F, size=18, bold=True, color=NAVY)
    ws["B3"] = "Pick a ward in the yellow cell - every number below is an INDEX/MATCH formula."
    ws["B3"].font = Font(name=F, size=10, color=MUTED)
    ws["B5"] = "Select ward"
    ws["B5"].font = Font(name=F, bold=True)
    ws["C5"] = "Bellandur"
    ws["C5"].fill = PatternFill("solid", fgColor="FFF2B3")
    ws["C5"].font = Font(name=F, bold=True, color="0000FF")
    ws["C5"].border = Border(top=thin, bottom=thin, left=thin, right=thin)
    dv = DataValidation(type="list", formula1="=q_wards!$B$2:$B$300", allow_blank=False)
    ws.add_data_validation(dv)
    dv.add("C5")
    rows = [("Zone", "C", None), ("Population", "D", "#,##0"), ("Total complaints", "G", "#,##0"),
            ("Complaints per 10k residents", "H", "0.0"), ("Open complaints", "I", "#,##0"),
            ("Avg resolution (hours)", "J", "0.0"), ("SLA breach %", "K", '0.0"%"'),
            ("Avg citizen rating", "L", "0.00"), ("City rank (complaint burden)", "M", "0"),
            ("Rank in zone (SLA breach)", "N", "0"), ("Health flag", "O", None)]
    for i, (label, col, fmt) in enumerate(rows):
        r = 7 + i
        ws[f"B{r}"] = label
        body(ws[f"B{r}"], color=MUTED)
        ws[f"C{r}"] = f'=IFERROR(INDEX(q_wards!${col}:${col},MATCH($C$5,q_wards!$B:$B,0)),"-")'
        body(ws[f"C{r}"], fmt=fmt, bold=True, align="right")
    ws["B19"] = "City average SLA breach %"
    body(ws["B19"], color=MUTED)
    ws["C19"] = "=AVERAGE(q_wards!$K:$K)"
    body(ws["C19"], fmt='0.0"%"', bold=True, align="right")
    ws["B20"] = "This ward vs city average"
    body(ws["B20"], color=MUTED)
    ws["C20"] = '=IFERROR(IF(C13>C19,"Worse than city avg","Better than city avg"),"-")'
    body(ws["C20"], bold=True, align="right")
    for flag, color in [("Critical", "C0392B"), ("Watch", "D68910"), ("Healthy", "1E8449")]:
        ws.conditional_formatting.add("C17", CellIsRule(operator="equal", formula=[f'"{flag}"'],
                                                        font=Font(color=color, bold=True)))


def build_readme_sheet(wb):
    ws = wb.create_sheet("How to Refresh")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["B"].width = 110
    lines = [
        ("Make this workbook auto-refresh (one-time setup, ~5 minutes)", True),
        ("1. Run the pipeline in live mode:  python src/run_pipeline.py --loop 1", False),
        ("2. For each q_ sheet: select all (Ctrl+A) > Delete, then Data > Get Data > From File > From Text/CSV.", False),
        ("   Pick the matching CSV in data/processed/ (shown in the A1 comment of each q_ sheet) > Load To... >", False),
        ("   Table > Existing worksheet > =q_xxx!$A$1.", False),
        ("3. Data > Queries & Connections > right-click each query > Properties >", False),
        ("   tick 'Refresh every 1 minutes' and 'Refresh data when opening the file'.", False),
        ("4. Done: the Dashboard and Ward Lookup update by themselves every minute while the pipeline runs.", False),
        ("Full guide with screenshots-in-words: excel/EXCEL_AUTO_REFRESH.md", False),
        ("", False),
        ("Colour key: yellow cell = input you can change; everything else is a formula.", False),
        ("Data note: complaint records are a simulated prototype for 48 real Bengaluru wards; weather and air", False),
        ("quality come from the Open-Meteo API. Swap in the real BBMP grievance export - see README.", False),
    ]
    for i, (t, bold) in enumerate(lines):
        c = ws.cell(2 + i, 2, t)
        c.font = Font(name=F, size=13 if bold else 10, bold=bold, color=NAVY if bold else INK)


def main():
    import sys
    if OUT.exists() and "--force" not in sys.argv:
        print(f"{OUT.name} already exists - not overwriting (it may hold your Power Query connections). "
              "Use --force to rebuild it.")
        return
    wb = Workbook()
    write_query_sheets(wb)
    calc = build_calc(wb)
    build_dashboard(wb, calc)
    build_ward_lookup(wb)
    build_readme_sheet(wb)
    order = ["Dashboard", "Ward Lookup", "How to Refresh", "Calc"] + list(QUERIES)
    wb._sheets = [wb[n] for n in order]
    wb.active = 0
    OUT.parent.mkdir(exist_ok=True)
    wb.save(OUT)
    print(f"Saved {OUT}")


if __name__ == "__main__":
    main()
