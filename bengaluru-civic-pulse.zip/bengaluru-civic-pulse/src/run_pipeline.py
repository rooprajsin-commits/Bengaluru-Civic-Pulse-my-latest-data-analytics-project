"""
Bengaluru Civic Pulse - pipeline runner.

    python src/run_pipeline.py              # run once
    python src/run_pipeline.py --loop 1     # LIVE SHOWCASE: refresh every 1 minute
    python src/run_pipeline.py --reset      # wipe the simulated history and start fresh

Each run: Open-Meteo API -> grievance stream -> clean/transform -> SQLite (+ optional
PostgreSQL) -> CSV exports. Excel and Power BI pick the new numbers up on their own refresh.
"""
import argparse
import logging
import sys
import time

import pandas as pd

import config
import api_client
import data_generator
import etl

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s",
                    datefmt="%H:%M:%S")
log = logging.getLogger("civic_pulse")


def run_once():
    t0 = time.time()
    now = pd.Timestamp.now().floor("min")
    before = 0
    if data_generator.STATE_FILE.exists():
        before = sum(1 for _ in open(data_generator.STATE_FILE, encoding="utf-8")) - 1

    weather = api_client.get_weather_daily()
    aq = api_client.get_air_quality()
    raw = data_generator.get_grievances(weather, now)
    wards = data_generator.load_wards()

    tables = etl.transform_all(raw, weather, aq, wards, now)
    con = etl.load_sqlite(tables)
    etl.load_postgres(tables)
    fg = tables["fact_grievance"]
    etl.log_refresh(con, len(fg), len(raw) - before, weather["source"].iloc[-1], aq["source"].iloc[-1],
                    time.time() - t0, now)
    etl.export_csv(con, tables)
    con.close()
    log.info("Refresh done in %.1fs | %s complaints | %s open | exports in %s",
             time.time() - t0, f"{len(fg):,}", f"{fg['is_open'].sum():,}", config.PROCESSED_DIR)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--loop", type=float, metavar="MINUTES", help="keep refreshing every N minutes")
    ap.add_argument("--reset", action="store_true", help="delete simulated history + caches first")
    args = ap.parse_args()

    if args.reset:
        for f in (data_generator.STATE_FILE, api_client.WEATHER_CACHE, api_client.AQ_CACHE, config.DB_PATH):
            f.unlink(missing_ok=True)
        log.info("Reset complete")

    run_once()
    if args.loop:
        log.info("Live mode: refreshing every %s minute(s). Press Ctrl+C to stop.", args.loop)
        try:
            while True:
                time.sleep(args.loop * 60)
                try:
                    run_once()
                except Exception:                      # keep the showcase alive
                    log.exception("Refresh failed - will retry next cycle")
        except KeyboardInterrupt:
            log.info("Stopped.")


if __name__ == "__main__":
    sys.exit(main())
