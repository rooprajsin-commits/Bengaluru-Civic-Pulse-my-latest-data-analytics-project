"""
Central configuration for Bengaluru Civic Pulse.
Every path, API endpoint and business rule lives here so the rest of the code stays clean.
"""
from pathlib import Path
import os

# ---------- Paths ----------
ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "data" / "raw"
PROCESSED_DIR = ROOT / "data" / "processed"
DB_PATH = ROOT / "data" / "db" / "civic_pulse.db"
SQL_DIR = ROOT / "sql"
REPORTS_DIR = ROOT / "reports"
for d in (RAW_DIR, PROCESSED_DIR, DB_PATH.parent, REPORTS_DIR):
    d.mkdir(parents=True, exist_ok=True)

# Optional: put a real BBMP grievance export here and the pipeline will use it
# instead of the simulated data (see README -> "Using the real BBMP dataset").
REAL_GRIEVANCE_CSV = RAW_DIR / "bbmp_grievances_real.csv"

# Optional: PostgreSQL connection for the Power BI DirectQuery live demo.
# Example (PowerShell):  $env:CIVIC_PG_DSN="host=localhost dbname=civic_pulse user=postgres password=secret"
PG_DSN = os.getenv("CIVIC_PG_DSN", "")

# ---------- Data window ----------
HISTORY_START = "2025-01-01"   # grievance + weather history starts here
RANDOM_SEED = 42

# ---------- Open-Meteo APIs (free, no API key needed) ----------
WEATHER_ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"
WEATHER_FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
AIR_QUALITY_URL = "https://air-quality-api.open-meteo.com/v1/air-quality"
API_TIMEZONE = "Asia/Kolkata"
API_TIMEOUT = 20

# ---------- BBMP zones (8-zone structure used in BBMP's published data) ----------
# Approximate zone centroids, used to pull zone-level weather & air quality from the API.
ZONES = {
    "East":          (12.985, 77.620),
    "West":          (12.985, 77.555),
    "South":         (12.925, 77.585),
    "Mahadevapura":  (12.975, 77.715),
    "Bommanahalli":  (12.900, 77.630),
    "Yelahanka":     (13.090, 77.600),
    "RR Nagar":      (12.925, 77.510),
    "Dasarahalli":   (13.040, 77.505),
}

# ---------- Complaint categories ----------
# share   = share of all complaints
# sla_hrs = target resolution time (hours) used for SLA-breach analysis (project assumption)
# rain    = how strongly daily rainfall pushes this category up (0 = not at all)
CATEGORIES = {
    "Garbage & Waste":        {"share": 0.30, "sla_hrs": 24,  "rain": 0.15,
                               "subs": ["Garbage not collected", "Black spot", "Burning of garbage", "Debris dumping"]},
    "Roads & Potholes":       {"share": 0.18, "sla_hrs": 72,  "rain": 0.90,
                               "subs": ["Pothole", "Road damaged", "Footpath broken", "Road cutting not restored"]},
    "Streetlights":           {"share": 0.16, "sla_hrs": 48,  "rain": 0.25,
                               "subs": ["Light not working", "Light on during day", "New light requested"]},
    "Drainage & Waterlogging":{"share": 0.10, "sla_hrs": 48,  "rain": 1.60,
                               "subs": ["Stormwater drain blocked", "Road waterlogged", "Sewage overflow"]},
    "Stray Animals":          {"share": 0.08, "sla_hrs": 96,  "rain": 0.00,
                               "subs": ["Stray dog menace", "Dog bite", "Animal carcass"]},
    "Trees & Parks":          {"share": 0.07, "sla_hrs": 72,  "rain": 0.70,
                               "subs": ["Tree fallen", "Branch pruning", "Park maintenance"]},
    "Mosquito & Health":      {"share": 0.06, "sla_hrs": 72,  "rain": 0.60,
                               "subs": ["Fogging request", "Mosquito breeding", "Unhygienic eatery"]},
    "Encroachment & Others":  {"share": 0.05, "sla_hrs": 120, "rain": 0.00,
                               "subs": ["Footpath encroachment", "Illegal hoarding", "Other"]},
}

CHANNELS = {"Sahaaya App": 0.42, "Helpline 1533": 0.28, "WhatsApp": 0.18, "Web Portal": 0.12}

# How many complaints per 10,000 residents per day (simulation baseline)
BASE_DAILY_RATE_PER_10K = 0.55
