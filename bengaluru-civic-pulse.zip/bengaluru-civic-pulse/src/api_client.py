"""
EXTRACT step - live data from the Open-Meteo REST APIs (free, no key).

* Daily weather (rainfall, temperature) for each BBMP zone  -> weather_daily
* Hourly air quality (PM2.5, PM10, US AQI) for each zone   -> air_quality_hourly

Results are cached in data/raw/. If the API cannot be reached (offline demo, firewall),
the cache is reused; if there is no cache yet, realistic fallback data is simulated and
flagged with source = 'simulated' so it is never confused with real API data.
"""
from datetime import date, timedelta
import logging

import numpy as np
import pandas as pd
import requests

import config

log = logging.getLogger("civic_pulse.api")
WEATHER_CACHE = config.RAW_DIR / "weather_daily.csv"
AQ_CACHE = config.RAW_DIR / "air_quality_hourly.csv"
DAILY_VARS = "precipitation_sum,precipitation_hours,temperature_2m_max,temperature_2m_min"


def _get(url, params):
    r = requests.get(url, params=params, timeout=config.API_TIMEOUT)
    r.raise_for_status()
    return r.json()


def _daily_frame(payload, zone):
    d = payload["daily"]
    return pd.DataFrame({
        "zone": zone,
        "date": pd.to_datetime(d["time"]).date,
        "rain_mm": d["precipitation_sum"],
        "rain_hours": d["precipitation_hours"],
        "temp_max_c": d["temperature_2m_max"],
        "temp_min_c": d["temperature_2m_min"],
        "source": "open-meteo",
    })


def _fetch_weather_api(start: date, end: date) -> pd.DataFrame:
    """Archive API for older days + forecast API (past_days) for the most recent ~2 weeks."""
    frames = []
    archive_end = min(end, date.today() - timedelta(days=7))
    for zone, (lat, lon) in config.ZONES.items():
        base = {"latitude": lat, "longitude": lon, "daily": DAILY_VARS, "timezone": config.API_TIMEZONE}
        if start <= archive_end:
            p = _get(config.WEATHER_ARCHIVE_URL, {**base, "start_date": start.isoformat(),
                                                  "end_date": archive_end.isoformat()})
            frames.append(_daily_frame(p, zone))
        p = _get(config.WEATHER_FORECAST_URL, {**base, "past_days": 14, "forecast_days": 1})
        frames.append(_daily_frame(p, zone))
    df = pd.concat(frames, ignore_index=True)
    df = df[(df["date"] >= start) & (df["date"] <= end)]
    # forecast rows (added last) win over archive rows for overlapping days
    return df.drop_duplicates(["zone", "date"], keep="last")


def _simulate_weather(start: date, end: date) -> pd.DataFrame:
    """Fallback only: Bengaluru-like seasonal rainfall (SW + NE monsoon) per zone."""
    rng = np.random.default_rng(config.RANDOM_SEED)
    days = pd.date_range(start, end, freq="D")
    # mean daily rain (mm) by month, roughly following Bengaluru climatology
    monthly_mean = {1: 0.1, 2: 0.2, 3: 0.5, 4: 1.5, 5: 4.0, 6: 3.0, 7: 3.5, 8: 4.5, 9: 6.5,
                    10: 6.0, 11: 2.0, 12: 0.5}
    rows = []
    city_wet = {d: rng.random() < min(0.85, monthly_mean[d.month] / 6) for d in days}
    for zone in config.ZONES:
        for d in days:
            wet = city_wet[d] and rng.random() < 0.85
            rain = rng.gamma(1.2, monthly_mean[d.month] * 1.6) if wet else 0.0
            tmax = 29 + 4 * np.sin((d.dayofyear - 30) / 365 * 2 * np.pi) + rng.normal(0, 1)
            rows.append((zone, d.date(), round(rain, 1), round(min(24, rain / 2), 1),
                         round(tmax, 1), round(tmax - 10 + rng.normal(0, 0.8), 1), "simulated"))
    return pd.DataFrame(rows, columns=["zone", "date", "rain_mm", "rain_hours",
                                       "temp_max_c", "temp_min_c", "source"])


def get_weather_daily(start: str = config.HISTORY_START) -> pd.DataFrame:
    start_d, end_d = pd.to_datetime(start).date(), date.today()
    cache = None
    if WEATHER_CACHE.exists():
        cache = pd.read_csv(WEATHER_CACHE, parse_dates=["date"])
        cache["date"] = cache["date"].dt.date
    try:
        if cache is not None and (cache["source"] == "open-meteo").all() and cache["date"].min() <= start_d:
            # incremental refresh: only re-pull the last 14 days
            fresh = _fetch_weather_api(end_d - timedelta(days=14), end_d)
            df = pd.concat([cache, fresh]).drop_duplicates(["zone", "date"], keep="last")
        else:
            df = _fetch_weather_api(start_d, end_d)
        log.info("Weather: %s rows from Open-Meteo API", len(df))
    except Exception as exc:  # network blocked, API down, etc.
        if cache is not None:
            log.warning("Weather API unreachable (%s) - using cached data", exc.__class__.__name__)
            df = cache
            gap = pd.date_range(df["date"].max() + timedelta(days=1), end_d).date
            if len(gap):  # extend with simulated days so 'today' always exists
                df = pd.concat([df, _simulate_weather(gap[0], end_d)])
        else:
            log.warning("Weather API unreachable (%s) - simulating fallback data", exc.__class__.__name__)
            df = _simulate_weather(start_d, end_d)
    df = df.sort_values(["zone", "date"]).reset_index(drop=True)
    df.to_csv(WEATHER_CACHE, index=False)
    return df


# ---------------------------------------------------------------- air quality
def _simulate_aq(hours: pd.DatetimeIndex) -> pd.DataFrame:
    rng = np.random.default_rng(int(hours[-1].timestamp()) % 10_000)
    rows = []
    zone_bias = {"Mahadevapura": 1.25, "Dasarahalli": 1.3, "East": 1.1, "Bommanahalli": 1.15}
    for zone in config.ZONES:
        b = zone_bias.get(zone, 1.0)
        for h in hours:
            traffic = 1 + 0.45 * (h.hour in (8, 9, 10, 18, 19, 20, 21))
            pm25 = max(5, rng.normal(28, 7) * b * traffic)
            pm10 = pm25 * rng.uniform(1.6, 2.1)
            rows.append((zone, h, round(pm25, 1), round(pm10, 1), round(min(300, pm25 * 2.9), 0), "simulated"))
    return pd.DataFrame(rows, columns=["zone", "timestamp", "pm2_5", "pm10", "us_aqi", "source"])


def get_air_quality(past_days: int = 30) -> pd.DataFrame:
    try:
        frames = []
        for zone, (lat, lon) in config.ZONES.items():
            p = _get(config.AIR_QUALITY_URL, {"latitude": lat, "longitude": lon,
                                              "hourly": "pm2_5,pm10,us_aqi", "past_days": past_days,
                                              "forecast_days": 1, "timezone": config.API_TIMEZONE})
            h = p["hourly"]
            frames.append(pd.DataFrame({"zone": zone, "timestamp": pd.to_datetime(h["time"]),
                                        "pm2_5": h["pm2_5"], "pm10": h["pm10"], "us_aqi": h["us_aqi"],
                                        "source": "open-meteo"}))
        df = pd.concat(frames, ignore_index=True)
        df = df[df["timestamp"] <= pd.Timestamp.now()]       # drop forecast hours
        log.info("Air quality: %s hourly rows from Open-Meteo API", len(df))
    except Exception as exc:
        log.warning("Air-quality API unreachable (%s) - simulating fallback data", exc.__class__.__name__)
        now = pd.Timestamp.now().floor("h")
        df = _simulate_aq(pd.date_range(now - pd.Timedelta(days=past_days), now, freq="h"))
    df = df.dropna(subset=["pm2_5"]).reset_index(drop=True)
    df.to_csv(AQ_CACHE, index=False)
    return df
