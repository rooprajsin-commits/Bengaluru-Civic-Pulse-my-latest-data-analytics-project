"""
Python EDA - runs SQL against the SQLite warehouse, does the statistics with pandas,
saves charts to reports/ and writes reports/insights.md (numbers update every run).

    python src/analysis.py
"""
import sqlite3

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import config

BLUE, ORANGE, AQUA, GREY = "#2a78d6", "#eb6834", "#1baf7a", "#8a8984"
INK, MUTED = "#0b0b0b", "#52514e"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": "#c9c8c3",
                     "axes.labelcolor": MUTED, "xtick.color": MUTED, "ytick.color": MUTED,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
                     "grid.color": "#ecebe7", "grid.linewidth": 0.8, "axes.axisbelow": True,
                     "axes.titleweight": "bold", "axes.titlesize": 12, "axes.titlecolor": INK})


def q(con, sql):
    return pd.read_sql(sql, con)


def save(fig, name):
    fig.tight_layout()
    fig.savefig(config.REPORTS_DIR / name, dpi=150)
    plt.close(fig)


def main():
    con = sqlite3.connect(config.DB_PATH)
    kpi = q(con, "SELECT * FROM vw_kpi_summary").iloc[0]
    zone = q(con, "SELECT * FROM vw_zone_summary ORDER BY sla_breach_pct DESC")
    cat = q(con, "SELECT * FROM vw_category_sla ORDER BY complaints DESC")
    daily = q(con, "SELECT * FROM vw_daily_rain_vs_complaints ORDER BY date")
    monthly = q(con, "SELECT * FROM vw_monthly_trend ORDER BY year_month")
    wards = q(con, "SELECT * FROM vw_ward_scorecard ORDER BY sla_breach_pct DESC")
    src = q(con, "SELECT weather_source FROM etl_refresh_log ORDER BY run_id DESC LIMIT 1").iloc[0, 0]

    # ---- statistics
    daily = daily.dropna(subset=["city_rain_mm"])
    r = daily["city_rain_mm"].corr(daily["rain_sensitive_complaints"])
    band = daily.groupby("rain_band")[["complaints", "pothole_complaints", "waterlogging_complaints"]].mean()
    dry, heavy = band.iloc[0], band.iloc[-1]
    uplift_pothole = (heavy["pothole_complaints"] / dry["pothole_complaints"] - 1) * 100
    uplift_water = (heavy["waterlogging_complaints"] / dry["waterlogging_complaints"] - 1) * 100
    # lagged effect: does yesterday's rain predict today's pothole complaints?
    daily["rain_lag1"] = daily["city_rain_mm"].shift(1)
    r_lag = daily["rain_lag1"].corr(daily["pothole_complaints"])

    # ---- chart 1: complaints per 10k residents by zone
    z = zone.sort_values("complaints_per_10k")
    fig, ax = plt.subplots(figsize=(8, 4.2))
    ax.barh(z["zone"], z["complaints_per_10k"], color=BLUE, height=0.6)
    for y, v in enumerate(z["complaints_per_10k"]):
        ax.text(v + 8, y, f"{v:,.0f}", va="center", color=MUTED, fontsize=9)
    ax.set_title("Complaints per 10,000 residents, by BBMP zone")
    ax.set_xlabel("complaints per 10k residents")
    ax.grid(axis="y", visible=False)
    save(fig, "01_zone_burden.png")

    # ---- chart 2: SLA breach % by category
    c = cat.sort_values("sla_breach_pct")
    fig, ax = plt.subplots(figsize=(8, 4.2))
    colors = [ORANGE if s == 1 else GREY for s in c["rain_sensitive"]]
    ax.barh(c["category"], c["sla_breach_pct"], color=colors, height=0.6)
    for y, v in enumerate(c["sla_breach_pct"]):
        ax.text(v + 0.6, y, f"{v:.0f}%", va="center", color=MUTED, fontsize=9)
    ax.set_title("SLA breach rate by complaint category  (orange = rain-sensitive)")
    ax.set_xlabel("% of complaints resolved later than SLA")
    ax.grid(axis="y", visible=False)
    save(fig, "02_category_sla.png")

    # ---- chart 3: rain band vs average daily complaints (one axis, small multiples)
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.8), sharey=False)
    labels = [b.split(" ", 1)[1].replace(" (", "\n(") for b in band.index]
    for ax, col, title, color in [(axes[0], "pothole_complaints", "Pothole complaints / day", BLUE),
                                  (axes[1], "waterlogging_complaints", "Waterlogging complaints / day", AQUA)]:
        ax.bar(labels, band[col], color=color, width=0.6)
        for x, v in enumerate(band[col]):
            ax.text(x, v + 0.5, f"{v:.0f}", ha="center", color=MUTED, fontsize=9)
        ax.set_title(title, fontsize=11)
        ax.tick_params(axis="x", labelsize=8)
        ax.grid(axis="x", visible=False)
    fig.suptitle("Rainfall (Open-Meteo API) vs daily complaints", fontweight="bold")
    save(fig, "03_rain_vs_complaints.png")

    # ---- chart 4: daily complaints trend with 7-day average
    d = daily.copy()
    d["date"] = pd.to_datetime(d["date"])
    fig, ax = plt.subplots(figsize=(10, 3.8))
    ax.plot(d["date"], d["complaints"], color="#b9d3f2", linewidth=1, label="daily")
    ax.plot(d["date"], d["complaints_7d_avg"], color=BLUE, linewidth=2, label="7-day average")
    ax.set_title("Daily complaints across Bengaluru")
    ax.legend(frameon=False, loc="upper left")
    ax.grid(axis="x", visible=False)
    save(fig, "04_daily_trend.png")

    # ---- insights.md
    worst_zone, best_zone = zone.iloc[0], zone.iloc[-1]
    worst_wards = wards.head(5)
    top_cat = cat.iloc[0]
    md = f"""# Bengaluru Civic Pulse - key insights

_Auto-generated by `src/analysis.py` on {pd.Timestamp.now():%d %b %Y %H:%M}. Weather source: **{src}**._

## Headline numbers
| KPI | Value |
|---|---|
| Total complaints | {int(kpi.total_complaints):,} |
| Open right now | {int(kpi.open_complaints):,} |
| Resolution rate | {kpi.resolution_rate:.1%} |
| Avg resolution time | {kpi.avg_resolution_hours:.1f} hours |
| SLA breach rate | {kpi.sla_breach_rate:.1%} |
| Avg citizen rating | {kpi.avg_citizen_rating:.2f} / 5 |

## Findings
1. **Rain drives road and drain complaints.** On heavy-rain days (20 mm+) pothole complaints are
   **{uplift_pothole:+.0f}%** and waterlogging complaints **{uplift_water:+.0f}%** versus dry days.
   Correlation of daily rainfall with rain-sensitive complaints: **r = {r:.2f}**
   (yesterday's rain vs today's pothole complaints: r = {r_lag:.2f}).
   *Action:* pre-position pothole and desilting crews when the forecast shows heavy rain.
2. **Peripheral zones are under-served.** **{worst_zone.zone}** breaches SLA on
   **{worst_zone.sla_breach_pct:.0f}%** of complaints vs **{best_zone.sla_breach_pct:.0f}%** in
   **{best_zone.zone}**, and its citizen rating is {worst_zone.avg_rating:.2f} vs {best_zone.avg_rating:.2f}.
3. **{top_cat.category}** is the largest category ({top_cat.share_pct:.0f}% of all complaints).
4. **Wards to prioritise** (highest SLA breach): {", ".join(f"{w.ward_name} ({w.sla_breach_pct:.0f}%)" for w in worst_wards.itertuples())}.
5. **Low ratings follow late fixes:** categories with the highest breach rates also have the lowest ratings.

## Charts
![zone](01_zone_burden.png)
![category](02_category_sla.png)
![rain](03_rain_vs_complaints.png)
![trend](04_daily_trend.png)
"""
    (config.REPORTS_DIR / "insights.md").write_text(md, encoding="utf-8")
    print(md)
    con.close()


if __name__ == "__main__":
    main()
