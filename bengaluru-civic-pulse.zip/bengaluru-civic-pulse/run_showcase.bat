@echo off
REM Bengaluru Civic Pulse - live showcase: refresh every 1 minute (Ctrl+C to stop)
cd /d "%~dp0"
python src\run_pipeline.py
python src\analysis.py
python src\build_excel_dashboard.py
start "" "excel\Civic_Pulse_Dashboard.xlsx"
python src\run_pipeline.py --loop 1
