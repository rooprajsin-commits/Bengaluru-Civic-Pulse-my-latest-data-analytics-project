-- =====================================================================
-- Bengaluru Civic Pulse  |  02_views.sql
-- Reporting views. Python exports each view to data/processed/*.csv,
-- which Excel (Power Query) and Power BI read on every refresh.
-- Skills shown: CTEs, CASE, aggregates, window functions (RANK, LAG,
-- running totals), date functions, joins across a star schema.
-- =====================================================================

-- 1) Headline KPIs (one row) ------------------------------------------
CREATE VIEW vw_kpi_summary AS
WITH g AS (SELECT * FROM fact_grievance),
     latest AS (SELECT MAX(created_date) AS today FROM g)
SELECT
    COUNT(*)                                                         AS total_complaints,
    SUM(is_open)                                                     AS open_complaints,
    SUM(CASE WHEN status IN ('Resolved','Closed') THEN 1 ELSE 0 END) AS resolved_complaints,
    ROUND(1.0 * SUM(CASE WHEN status IN ('Resolved','Closed') THEN 1 ELSE 0 END)
          / NULLIF(SUM(CASE WHEN status <> 'Rejected' THEN 1 ELSE 0 END), 0), 4) AS resolution_rate,
    ROUND(AVG(resolution_hours), 1)                                  AS avg_resolution_hours,
    ROUND(1.0 * SUM(sla_breached) / COUNT(*), 4)                     AS sla_breach_rate,
    ROUND(AVG(citizen_rating), 2)                                    AS avg_citizen_rating,
    SUM(CASE WHEN created_date = (SELECT today FROM latest) THEN 1 ELSE 0 END) AS complaints_today,
    SUM(CASE WHEN created_date >= DATE((SELECT today FROM latest), '-6 day') THEN 1 ELSE 0 END) AS complaints_last_7d,
    (SELECT MAX(refreshed_at) FROM etl_refresh_log)                  AS last_refreshed
FROM g;

-- 2) Zone summary --------------------------------------------------------
CREATE VIEW vw_zone_summary AS
WITH pop AS (SELECT zone, COUNT(*) AS wards, SUM(population) AS population
             FROM dim_ward GROUP BY zone)
SELECT
    w.zone,
    p.wards,
    p.population,
    COUNT(g.complaint_id)                                             AS complaints,
    ROUND(10000.0 * COUNT(g.complaint_id) / p.population, 1)          AS complaints_per_10k,
    SUM(g.is_open)                                                    AS open_complaints,
    ROUND(AVG(g.resolution_hours), 1)                                 AS avg_resolution_hours,
    ROUND(100.0 * SUM(g.sla_breached) / COUNT(g.complaint_id), 1)     AS sla_breach_pct,
    ROUND(AVG(g.citizen_rating), 2)                                   AS avg_rating
FROM dim_ward w
JOIN pop p ON p.zone = w.zone
LEFT JOIN fact_grievance g ON g.ward_no = w.ward_no
GROUP BY w.zone, p.wards, p.population;

-- 3) Ward scorecard with ranking (window functions) -----------------------
CREATE VIEW vw_ward_scorecard AS
WITH ward_stats AS (
    SELECT w.ward_no, w.ward_name, w.zone, w.population, w.latitude, w.longitude,
           COUNT(g.complaint_id)                                    AS complaints,
           ROUND(10000.0 * COUNT(g.complaint_id) / w.population, 1) AS complaints_per_10k,
           SUM(g.is_open)                                           AS open_complaints,
           ROUND(AVG(g.resolution_hours), 1)                        AS avg_resolution_hours,
           ROUND(100.0 * SUM(g.sla_breached) / COUNT(g.complaint_id), 1) AS sla_breach_pct,
           ROUND(AVG(g.citizen_rating), 2)                          AS avg_rating
    FROM dim_ward w
    JOIN fact_grievance g ON g.ward_no = w.ward_no
    GROUP BY w.ward_no
)
SELECT *,
       RANK() OVER (ORDER BY complaints_per_10k DESC)                 AS city_rank_burden,
       RANK() OVER (PARTITION BY zone ORDER BY sla_breach_pct DESC)   AS zone_rank_sla_breach,
       CASE WHEN sla_breach_pct >= 35 THEN 'Critical'
            WHEN sla_breach_pct >= 25 THEN 'Watch'
            ELSE 'Healthy' END                                        AS health_flag
FROM ward_stats;

-- 4) Monthly trend with month-over-month growth (LAG) ----------------------
CREATE VIEW vw_monthly_trend AS
WITH m AS (
    SELECT d.year_month,
           COUNT(*)                                                 AS complaints,
           SUM(CASE WHEN dc.rain_sensitive = 1 THEN 1 ELSE 0 END)   AS rain_sensitive_complaints,
           ROUND(AVG(g.resolution_hours), 1)                        AS avg_resolution_hours,
           ROUND(100.0 * SUM(g.sla_breached) / COUNT(*), 1)         AS sla_breach_pct
    FROM fact_grievance g
    JOIN dim_date d      ON d.date = g.created_date
    JOIN dim_category dc ON dc.category = g.category
    GROUP BY d.year_month
),
r AS (
    SELECT d.year_month, ROUND(SUM(w.rain_mm) / 8.0, 1) AS city_rain_mm   -- avg over 8 zones
    FROM fact_weather_daily w JOIN dim_date d ON d.date = w.date
    GROUP BY d.year_month
)
SELECT m.*,
       r.city_rain_mm,
       LAG(m.complaints) OVER (ORDER BY m.year_month)                 AS prev_month_complaints,
       ROUND(100.0 * (m.complaints - LAG(m.complaints) OVER (ORDER BY m.year_month))
             / LAG(m.complaints) OVER (ORDER BY m.year_month), 1)     AS mom_growth_pct,
       SUM(m.complaints) OVER (ORDER BY m.year_month)                 AS running_total
FROM m LEFT JOIN r ON r.year_month = m.year_month;

-- 5) Category performance vs SLA ------------------------------------------
CREATE VIEW vw_category_sla AS
SELECT g.category,
       dc.sla_hours,
       dc.rain_sensitive,
       COUNT(*)                                                  AS complaints,
       ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM fact_grievance), 1) AS share_pct,
       SUM(g.is_open)                                            AS open_complaints,
       ROUND(AVG(g.resolution_hours), 1)                         AS avg_resolution_hours,
       ROUND(100.0 * SUM(g.sla_breached) / COUNT(*), 1)          AS sla_breach_pct,
       ROUND(AVG(g.citizen_rating), 2)                           AS avg_rating
FROM fact_grievance g
JOIN dim_category dc ON dc.category = g.category
GROUP BY g.category;

-- 6) Daily rainfall (API) vs complaints - the key insight -------------------
CREATE VIEW vw_daily_rain_vs_complaints AS
WITH rain AS (
    SELECT date, ROUND(AVG(rain_mm), 1) AS city_rain_mm, ROUND(AVG(temp_max_c), 1) AS temp_max_c
    FROM fact_weather_daily GROUP BY date
),
c AS (
    SELECT g.created_date AS date,
           COUNT(*)                                                AS complaints,
           SUM(CASE WHEN dc.rain_sensitive = 1 THEN 1 ELSE 0 END)  AS rain_sensitive_complaints,
           SUM(CASE WHEN g.category = 'Roads & Potholes' THEN 1 ELSE 0 END)        AS pothole_complaints,
           SUM(CASE WHEN g.category = 'Drainage & Waterlogging' THEN 1 ELSE 0 END) AS waterlogging_complaints
    FROM fact_grievance g JOIN dim_category dc ON dc.category = g.category
    GROUP BY g.created_date
)
SELECT c.*, rain.city_rain_mm, rain.temp_max_c,
       CASE WHEN rain.city_rain_mm = 0 THEN '0 Dry'
            WHEN rain.city_rain_mm < 5 THEN '1 Light (<5mm)'
            WHEN rain.city_rain_mm < 20 THEN '2 Moderate (5-20mm)'
            ELSE '3 Heavy (20mm+)' END                                AS rain_band,
       ROUND(AVG(c.complaints) OVER (ORDER BY c.date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW), 1) AS complaints_7d_avg
FROM c LEFT JOIN rain ON rain.date = c.date;

-- 7) When do citizens complain? (hour x weekday heatmap) ---------------------
CREATE VIEW vw_hourly_pattern AS
SELECT d.day_name,
       CAST(strftime('%w', g.created_date) AS INTEGER) AS weekday_no,   -- 0 = Sunday
       g.created_hour,
       COUNT(*) AS complaints
FROM fact_grievance g JOIN dim_date d ON d.date = g.created_date
GROUP BY d.day_name, weekday_no, g.created_hour;

-- 8) Channel mix ----------------------------------------------------------
CREATE VIEW vw_channel_mix AS
SELECT channel,
       COUNT(*) AS complaints,
       ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM fact_grievance), 1) AS share_pct,
       ROUND(AVG(resolution_hours), 1) AS avg_resolution_hours
FROM fact_grievance GROUP BY channel;

-- 9) Live air quality by zone (latest hour + last-24h average, from API) ---------
CREATE VIEW vw_air_quality_latest AS
WITH latest AS (SELECT zone, MAX(timestamp) AS ts FROM fact_air_quality_hourly GROUP BY zone)
SELECT a.zone,
       a.timestamp                         AS latest_reading,
       a.pm2_5, a.pm10, a.us_aqi,
       (SELECT ROUND(AVG(x.us_aqi), 0) FROM fact_air_quality_hourly x
         WHERE x.zone = a.zone AND x.timestamp > DATETIME(a.timestamp, '-24 hours')) AS us_aqi_24h_avg,
       CASE WHEN a.us_aqi <= 50 THEN 'Good'
            WHEN a.us_aqi <= 100 THEN 'Moderate'
            WHEN a.us_aqi <= 150 THEN 'Unhealthy (Sensitive)'
            ELSE 'Unhealthy' END           AS aqi_band,
       a.source
FROM fact_air_quality_hourly a
JOIN latest l ON l.zone = a.zone AND l.ts = a.timestamp;
