-- =====================================================================
-- Bengaluru Civic Pulse  |  01_schema.sql
-- Star schema: 3 dimensions + 3 fact tables + refresh log.
-- Written for SQLite (runs as-is); notes show MySQL / PostgreSQL types.
-- =====================================================================

DROP VIEW  IF EXISTS vw_kpi_summary;
DROP VIEW  IF EXISTS vw_zone_summary;
DROP VIEW  IF EXISTS vw_ward_scorecard;
DROP VIEW  IF EXISTS vw_monthly_trend;
DROP VIEW  IF EXISTS vw_category_sla;
DROP VIEW  IF EXISTS vw_daily_rain_vs_complaints;
DROP VIEW  IF EXISTS vw_hourly_pattern;
DROP VIEW  IF EXISTS vw_channel_mix;
DROP VIEW  IF EXISTS vw_air_quality_latest;

DROP TABLE IF EXISTS fact_grievance;
DROP TABLE IF EXISTS fact_weather_daily;
DROP TABLE IF EXISTS fact_air_quality_hourly;
DROP TABLE IF EXISTS dim_ward;
DROP TABLE IF EXISTS dim_zone;
DROP TABLE IF EXISTS dim_category;
DROP TABLE IF EXISTS dim_date;

-- ---------- Dimensions ----------
CREATE TABLE dim_zone (
    zone       TEXT PRIMARY KEY,                 -- one of the 8 BBMP zones
    latitude   REAL,                             -- zone centroid used for the weather / AQ API calls
    longitude  REAL
);

CREATE TABLE dim_ward (
    ward_no               INTEGER PRIMARY KEY,
    ward_name             TEXT    NOT NULL,      -- VARCHAR(80)
    zone                  TEXT    NOT NULL REFERENCES dim_zone(zone),
    assembly_constituency TEXT,
    population            INTEGER,
    area_sq_km            REAL,                  -- DECIMAL(6,2)
    density_per_sq_km     REAL,
    latitude              REAL,
    longitude             REAL
);

CREATE TABLE dim_category (
    category        TEXT PRIMARY KEY,
    sla_hours       INTEGER NOT NULL,
    rain_sensitive  INTEGER NOT NULL             -- 1 = complaints rise with rainfall (BOOLEAN)
);

CREATE TABLE dim_date (
    date          TEXT PRIMARY KEY,              -- DATE
    year          INTEGER,
    month         INTEGER,
    month_name    TEXT,
    year_month    TEXT,
    quarter       TEXT,
    day_name      TEXT,
    is_weekend    INTEGER,
    season        TEXT                           -- Summer / SW Monsoon / NE Monsoon / Winter
);

-- ---------- Facts ----------
CREATE TABLE fact_grievance (
    complaint_id        TEXT PRIMARY KEY,
    created_at          TEXT NOT NULL,           -- DATETIME / TIMESTAMP
    created_date        TEXT NOT NULL REFERENCES dim_date(date),
    created_hour        INTEGER,
    ward_no             INTEGER NOT NULL REFERENCES dim_ward(ward_no),
    category            TEXT NOT NULL REFERENCES dim_category(category),
    sub_category        TEXT,
    channel             TEXT,
    status              TEXT NOT NULL,           -- Registered / In Progress / Resolved / Closed / Rejected
    is_open             INTEGER NOT NULL,
    resolved_at         TEXT,
    resolution_hours    REAL,
    age_hours           REAL,
    sla_hours           INTEGER,
    sla_breached        INTEGER,                 -- 1 = took (or is taking) longer than SLA
    citizen_rating      INTEGER                  -- 1..5, only for closed complaints
);
CREATE INDEX ix_griev_date ON fact_grievance(created_date);
CREATE INDEX ix_griev_ward ON fact_grievance(ward_no);
CREATE INDEX ix_griev_cat  ON fact_grievance(category);

CREATE TABLE fact_weather_daily (
    zone        TEXT NOT NULL,
    date        TEXT NOT NULL REFERENCES dim_date(date),
    rain_mm     REAL,
    rain_hours  REAL,
    temp_max_c  REAL,
    temp_min_c  REAL,
    source      TEXT,                            -- 'open-meteo' (API) or 'simulated' (offline fallback)
    PRIMARY KEY (zone, date)
);

CREATE TABLE fact_air_quality_hourly (
    zone       TEXT NOT NULL,
    timestamp  TEXT NOT NULL,
    pm2_5      REAL,
    pm10       REAL,
    us_aqi     REAL,
    source     TEXT,
    PRIMARY KEY (zone, timestamp)
);

CREATE TABLE IF NOT EXISTS etl_refresh_log (
    run_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    refreshed_at    TEXT,
    grievance_rows  INTEGER,
    new_rows        INTEGER,
    weather_source  TEXT,
    aq_source       TEXT,
    duration_sec    REAL
);
