-- =====================================================================
-- Bengaluru Civic Pulse  |  03_analysis_queries.sql
-- Business questions answered in SQL (run in DB Browser for SQLite,
-- DBeaver, or:  sqlite3 data/db/civic_pulse.db < sql/03_analysis_queries.sql)
-- =====================================================================

-- Q1. Which 10 wards have the highest complaint burden per 10k residents?
SELECT ward_name, zone, complaints, complaints_per_10k, sla_breach_pct, health_flag
FROM vw_ward_scorecard
ORDER BY complaints_per_10k DESC
LIMIT 10;

-- Q2. Worst ward in every zone by SLA breach (window function + filter)
SELECT zone, ward_name, sla_breach_pct
FROM vw_ward_scorecard
WHERE zone_rank_sla_breach = 1
ORDER BY sla_breach_pct DESC;

-- Q3. Does rain increase pothole complaints? Average per day by rain band
SELECT rain_band,
       COUNT(*)                                AS days,
       ROUND(AVG(pothole_complaints), 1)       AS avg_pothole_per_day,
       ROUND(AVG(waterlogging_complaints), 1)  AS avg_waterlogging_per_day
FROM vw_daily_rain_vs_complaints
GROUP BY rain_band
ORDER BY rain_band;

-- Q4. Next-day effect: complaints on the day AFTER a heavy-rain day (LAG)
WITH d AS (
    SELECT date, pothole_complaints,
           LAG(city_rain_mm) OVER (ORDER BY date) AS rain_yesterday
    FROM vw_daily_rain_vs_complaints
)
SELECT CASE WHEN rain_yesterday >= 20 THEN 'After heavy rain' ELSE 'Normal day' END AS day_type,
       ROUND(AVG(pothole_complaints), 1) AS avg_pothole_complaints
FROM d
WHERE rain_yesterday IS NOT NULL
GROUP BY day_type;

-- Q5. Open complaints that have already breached SLA (the action list for today)
SELECT g.complaint_id, w.ward_name, w.zone, g.category, g.created_at,
       g.age_hours, g.sla_hours, ROUND(g.age_hours - g.sla_hours, 1) AS hours_overdue
FROM fact_grievance g
JOIN dim_ward w ON w.ward_no = g.ward_no
WHERE g.is_open = 1 AND g.sla_breached = 1
ORDER BY hours_overdue DESC
LIMIT 25;

-- Q6. Month-over-month growth and running total
SELECT year_month, complaints, prev_month_complaints, mom_growth_pct, running_total, city_rain_mm
FROM vw_monthly_trend
ORDER BY year_month;

-- Q7. Season comparison (SW monsoon vs rest of year) per category
SELECT g.category,
       ROUND(1.0 * SUM(CASE WHEN d.season = 'SW Monsoon' THEN 1 END)
             / COUNT(DISTINCT CASE WHEN d.season = 'SW Monsoon' THEN d.date END), 1) AS per_day_monsoon,
       ROUND(1.0 * SUM(CASE WHEN d.season <> 'SW Monsoon' THEN 1 END)
             / COUNT(DISTINCT CASE WHEN d.season <> 'SW Monsoon' THEN d.date END), 1) AS per_day_other
FROM fact_grievance g
JOIN dim_date d ON d.date = g.created_date
GROUP BY g.category
ORDER BY per_day_monsoon DESC;

-- Q8. Peak complaint hours (top 5 hour slots across the week)
SELECT created_hour, SUM(complaints) AS complaints
FROM vw_hourly_pattern
GROUP BY created_hour
ORDER BY complaints DESC
LIMIT 5;

-- Q9. Rating vs speed: does fixing within SLA improve citizen satisfaction?
SELECT CASE WHEN sla_breached = 1 THEN 'Breached SLA' ELSE 'Within SLA' END AS outcome,
       COUNT(*)                     AS closed_complaints,
       ROUND(AVG(citizen_rating),2) AS avg_rating
FROM fact_grievance
WHERE status = 'Closed'
GROUP BY outcome;

-- Q10. Zones with poor air quality right now (live API data)
SELECT zone, latest_reading, us_aqi, us_aqi_24h_avg, aqi_band
FROM vw_air_quality_latest
ORDER BY us_aqi DESC;

-- Q11. Pipeline health: last 10 automated refreshes
SELECT * FROM etl_refresh_log ORDER BY run_id DESC LIMIT 10;
