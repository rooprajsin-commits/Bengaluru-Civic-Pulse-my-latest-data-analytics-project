# Power BI build guide - Bengaluru Civic Pulse

Power BI Desktop is free (Windows). Building the report yourself takes about 60-90 minutes and is
the part interviewers ask about most, so every step is written out. Save the result as
`powerbi/Civic_Pulse.pbix`.

---

## 1. Load the data (Power Query)

1. Run the pipeline once so `data/processed/` has fresh CSVs: `python src/run_pipeline.py`
2. Power BI Desktop > **Transform data** > **Manage Parameters** > New
   - Name `DataFolder`, Type `Text`, Value = full path to `data\processed\` **with** the trailing `\`
3. For each table: **New Source > Blank Query > Advanced Editor**, paste the matching block from
   `powerquery_tables.m`, and rename the query exactly (`fact_grievance`, `dim_ward`, `dim_zone`,
   `dim_category`, `dim_date`, `fact_weather_daily`, `fact_air_quality_hourly`, `etl_refresh_log`).
4. **Close & Apply**.

Because every query is built on the `DataFolder` parameter, anyone can run your project by changing
one value.

## 2. Model (star schema)

Model view > drag to create these relationships (all single direction, many-to-one):

| From (many) | To (one) |
|---|---|
| fact_grievance[ward_no] | dim_ward[ward_no] |
| fact_grievance[category] | dim_category[category] |
| fact_grievance[created_date] | dim_date[date] |
| dim_ward[zone] | dim_zone[zone] |
| fact_weather_daily[zone] | dim_zone[zone] |
| fact_weather_daily[date] | dim_date[date] |
| fact_air_quality_hourly[zone] | dim_zone[zone] |

Then: select `dim_date` > **Table tools > Mark as date table** > column `date`.
Hide the foreign-key columns in the fact tables (right-click > Hide in report view) so report users
only see dimension fields.

```
            dim_date ─────────┬───────────────┐
                              │               │
 dim_category ── fact_grievance        fact_weather_daily
                      │                       │
                   dim_ward ──── dim_zone ────┤
                                              │
                                   fact_air_quality_hourly
```

## 3. Measures

Home > **Enter data** > name the table `_Measures` > Load. Select it and add every measure in
`measures.dax` (Modeling > New measure). Set formats: `%` for Resolution Rate, SLA Breach %,
MoM Growth %; one decimal for hours.

## 4. Theme

View > Themes > **Browse for themes** > `civic_pulse_theme.json`.

## 5. Report pages (16:9)

Put a **card with `[Last Refreshed Text]`** in the top-right of every page - it proves the dashboard
is live when you present.

### Page 1 - Executive Overview
- KPI cards: Total Complaints, Open Complaints, Resolution Rate, Avg Resolution Hours,
  SLA Breach %, Avg Citizen Rating, Complaints Today
- Line chart: X `dim_date[date]`, Y `Total Complaints` + `Complaints 7D Rolling Avg`
- Clustered bar: `dim_zone[zone]` by `Complaints per 10k Residents`
- Donut: `fact_grievance[channel]` by `Total Complaints`
- Slicers (one row, top): `dim_date[date]` (Between), `dim_zone[zone]`, `dim_category[category]`

### Page 2 - Zone & Ward Performance
- Map (Map or Azure Map visual): Latitude/Longitude from `dim_ward`, bubble size `Total Complaints`,
  tooltip `SLA Breach %`. *If maps are disabled in your settings: File > Options > Security > Map
  and filled map visuals.*
- Matrix: rows `dim_zone[zone]` > `dim_ward[ward_name]` (drill down), values Total Complaints,
  Complaints per 10k, Avg Resolution Hours, SLA Breach %, Avg Citizen Rating, Ward Rank by SLA Breach.
  Conditional formatting > Background on SLA Breach % > Field value > `SLA Color`.
- Bar: Top 10 wards by SLA Breach % (Filters pane > Top N = 10)

### Page 3 - Rain Impact (Open-Meteo API)
- Line chart: X `dim_date[date]`, Y `Rain-Sensitive Complaints` (one axis only).
- Column chart directly under it, same X axis: `Avg Daily Rain mm`. Stacking the two charts with a
  shared date axis reads better than a dual-axis chart.
- Scatter: Values `dim_date[date]`, X `Avg Daily Rain mm`, Y `Pothole Complaints`, trend line on
  (Analytics pane).
- Clustered bar: `dim_category[category]` by `Total Complaints`, filtered to `dim_date[season]`
  via a slicer (compare SW Monsoon vs Winter).
- Text box with the insight from `reports/insights.md` (for example "Pothole complaints rise ~87% on heavy-rain days").

### Page 4 - Live Operations
- Card: `Overdue Open Complaints` (red), `New Complaints Last Refresh`
- Table: open + overdue complaints - complaint_id, ward_name, category, created_at, age_hours,
  age_bucket; filter `is_open = 1`; sort by age_hours desc
- Bar: `fact_grievance[age_bucket]` by Open Complaints
- Bar: `dim_zone[zone]` by `Latest AQI`, background colour by `AQI Color`, tooltip `AQI Status`
- Line: `fact_air_quality_hourly[timestamp]` by average `us_aqi` (last 48 h, relative-time filter)

## 6. Auto refresh - three options

| Option | How it refreshes | Best for |
|---|---|---|
| **A. Desktop + CSV (Import)** | Click **Home > Refresh** after the pipeline runs | Building the report |
| **B. Live demo: PostgreSQL + DirectQuery + Automatic page refresh** | Visuals re-query the database every N seconds/minutes on their own | Interview / showcase |
| **C. Power BI Service + gateway** | Scheduled refresh (Pro licence allows a limited number of refreshes per day) | Sharing a link on your resume |

### Option B in detail (true hands-free live dashboard)
1. Install PostgreSQL (free) and create a database: `CREATE DATABASE civic_pulse;`
2. `pip install psycopg2-binary`
3. Tell the pipeline about it (PowerShell):
   `$env:CIVIC_PG_DSN="host=localhost dbname=civic_pulse user=postgres password=YOURPASS"`
4. Start live mode: `python src/run_pipeline.py --loop 1` - every minute it reloads PostgreSQL
   inside one transaction (no empty-table flicker).
5. Power BI Desktop > Get Data > **PostgreSQL database** > server `localhost`, database
   `civic_pulse`, **Data Connectivity mode: DirectQuery**. Select all tables, rebuild relationships
   and measures (same DAX works; `age_bucket` can be a DAX calculated column instead of Power Query).
6. Select the page background > Format > **Page refresh** > On > Auto page refresh every 1 minute.
   The KPI cards, `Last Refreshed Text` and the overdue table now tick over by themselves.

Note: automatic page refresh in the Power BI Service has a minimum interval set by the capacity
admin (shared capacity is more restricted than Desktop). Check Microsoft's current
"Automatic page refresh" documentation before relying on short intervals in the Service.

### Option C in detail
1. Publish (Home > Publish) to your workspace.
2. Install **On-premises data gateway (personal mode)** and sign in.
3. Dataset settings > Data source credentials > Gateway > Scheduled refresh > add times.
4. Keep `run_pipeline.py --loop 30` (or a Windows Task Scheduler job) running on the same PC.

## 7. Polish checklist
- Every visual has a clear title that states the insight, not just the field names
- One slicer row at the top of each page; sync slicers across pages (View > Sync slicers)
- Tooltips: add SLA Breach % and Avg Rating to zone/ward visuals
- Page navigation buttons (Insert > Buttons > Navigator > Page navigator)
- Take 4 screenshots of the pages and add them to `docs/screenshots/` for GitHub
