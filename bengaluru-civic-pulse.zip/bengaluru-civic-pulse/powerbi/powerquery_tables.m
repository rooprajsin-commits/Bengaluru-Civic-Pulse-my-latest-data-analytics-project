// =====================================================================
// Bengaluru Civic Pulse - Power Query (M) for Power BI Desktop
// How to use: Home > Transform data > New Source > Blank Query > Advanced Editor,
// paste ONE block per query and name the query exactly as the comment says.
// Step 0: create the parameter first (Manage Parameters > New):
//     Name: DataFolder   Type: Text
//     Value: C:\Projects\bengaluru-civic-pulse\data\processed\      <-- your path, keep the trailing \
// =====================================================================

// ---------- Query name: fact_grievance ----------
let
    Source   = Csv.Document(File.Contents(DataFolder & "fact_grievance.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Headers  = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Headers, {
                  {"complaint_id", type text}, {"created_at", type datetime}, {"created_date", type date},
                  {"created_hour", Int64.Type}, {"ward_no", Int64.Type}, {"category", type text},
                  {"sub_category", type text}, {"channel", type text}, {"status", type text},
                  {"is_open", Int64.Type}, {"resolved_at", type datetime}, {"resolution_hours", type number},
                  {"age_hours", type number}, {"sla_hours", Int64.Type}, {"sla_breached", Int64.Type},
                  {"citizen_rating", type number}}, "en-US"),
    // ageing buckets are a classic Power Query transformation worth showing
    AgeBucket = Table.AddColumn(Typed, "age_bucket", each
                  if [is_open] = 0 then "Closed"
                  else if [age_hours] <= 24 then "0-1 day"
                  else if [age_hours] <= 72 then "1-3 days"
                  else if [age_hours] <= 168 then "3-7 days"
                  else "7+ days", type text)
in
    AgeBucket

// ---------- Query name: dim_ward ----------
let
    Source  = Csv.Document(File.Contents(DataFolder & "dim_ward.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Headers = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed   = Table.TransformColumnTypes(Headers, {
                {"ward_no", Int64.Type}, {"ward_name", type text}, {"zone", type text},
                {"assembly_constituency", type text}, {"population", Int64.Type}, {"area_sq_km", type number},
                {"density_per_sq_km", type number}, {"latitude", type number}, {"longitude", type number}}, "en-US")
in
    Typed

// ---------- Query name: dim_zone ----------
let
    Source  = Csv.Document(File.Contents(DataFolder & "dim_zone.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Headers = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed   = Table.TransformColumnTypes(Headers, {{"zone", type text}, {"latitude", type number}, {"longitude", type number}}, "en-US")
in
    Typed

// ---------- Query name: dim_category ----------
let
    Source  = Csv.Document(File.Contents(DataFolder & "dim_category.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Headers = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed   = Table.TransformColumnTypes(Headers, {{"category", type text}, {"sla_hours", Int64.Type}, {"rain_sensitive", Int64.Type}}, "en-US")
in
    Typed

// ---------- Query name: dim_date ----------
let
    Source  = Csv.Document(File.Contents(DataFolder & "dim_date.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Headers = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed   = Table.TransformColumnTypes(Headers, {
                {"date", type date}, {"year", Int64.Type}, {"month", Int64.Type}, {"month_name", type text},
                {"year_month", type text}, {"quarter", type text}, {"day_name", type text},
                {"is_weekend", Int64.Type}, {"season", type text}}, "en-US")
in
    Typed

// ---------- Query name: fact_weather_daily ----------
let
    Source  = Csv.Document(File.Contents(DataFolder & "fact_weather_daily.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Headers = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed   = Table.TransformColumnTypes(Headers, {
                {"zone", type text}, {"date", type date}, {"rain_mm", type number}, {"rain_hours", type number},
                {"temp_max_c", type number}, {"temp_min_c", type number}, {"source", type text}}, "en-US")
in
    Typed

// ---------- Query name: fact_air_quality_hourly ----------
let
    Source  = Csv.Document(File.Contents(DataFolder & "fact_air_quality_hourly.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Headers = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed   = Table.TransformColumnTypes(Headers, {
                {"zone", type text}, {"timestamp", type datetime}, {"pm2_5", type number},
                {"pm10", type number}, {"us_aqi", type number}, {"source", type text}}, "en-US")
in
    Typed

// ---------- Query name: etl_refresh_log ----------
let
    Source  = Csv.Document(File.Contents(DataFolder & "etl_refresh_log.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Headers = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed   = Table.TransformColumnTypes(Headers, {
                {"run_id", Int64.Type}, {"refreshed_at", type datetime}, {"grievance_rows", Int64.Type},
                {"new_rows", Int64.Type}, {"weather_source", type text}, {"aq_source", type text},
                {"duration_sec", type number}}, "en-US")
in
    Typed
